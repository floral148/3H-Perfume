const WHATSAPP_NUMBER = "923001234567"; // Replace with your WhatsApp number, e.g. 923001234567
const products=[
 {id:1,name:"Oud Royale",price:4500,desc:"Rich oud, amber and warm woods."},
 {id:2,name:"Velvet Rose",price:4200,desc:"A soft floral blend with rose and musk."},
 {id:3,name:"Noir Intense",price:4800,desc:"Deep spices, leather and smooth vanilla."},
 {id:4,name:"Aqua 3H",price:3500,desc:"Fresh citrus, aquatic notes and clean musk."},
 {id:5,name:"Golden Musk",price:4000,desc:"Elegant musk with amber and subtle woods."},
 {id:6,name:"Royal Bloom",price:4300,desc:"Fruity florals with a refined creamy finish."}
];
let cart=JSON.parse(localStorage.getItem("3hCart")||"[]");
const money=n=>"Rs "+n.toLocaleString("en-PK");
function renderProducts(){document.getElementById("products").innerHTML=products.map(p=>`<article class="product"><div class="product-img"><div class="mini-bottle"><span>3H</span></div></div><div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p><span class="price">${money(p.price)}</span><button class="add" onclick="addToCart(${p.id})">ADD</button></div></article>`).join("")}
function addToCart(id){const p=products.find(x=>x.id===id), old=cart.find(x=>x.id===id);old?old.qty++:cart.push({...p,qty:1});save();openCart()}
function save(){localStorage.setItem("3hCart",JSON.stringify(cart));renderCart()}
function renderCart(){document.getElementById("cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0);document.getElementById("cartItems").innerHTML=cart.length?cart.map(x=>`<div class="cart-item"><div><b>${x.name}</b><br><small>${money(x.price)} × ${x.qty}</small></div><button class="remove" onclick="removeItem(${x.id})">Remove</button></div>`).join(""):`<p style="color:#888">Your cart is empty.</p>`;document.getElementById("cartTotal").textContent=money(cart.reduce((a,x)=>a+x.price*x.qty,0))}
function removeItem(id){cart=cart.filter(x=>x.id!==id);save()}
function openCart(){document.getElementById("cart").classList.add("open");document.getElementById("overlay").classList.add("open")}
function closeCart(){document.getElementById("cart").classList.remove("open");document.getElementById("overlay").classList.remove("open")}
function checkout(){if(!cart.length)return alert("Your cart is empty.");const lines=cart.map(x=>`${x.name} × ${x.qty} = ${money(x.price*x.qty)}`).join("%0A");const total=money(cart.reduce((a,x)=>a+x.price*x.qty,0));window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=Assalam-o-Alaikum%2C%20I%20want%20to%20order%3A%0A${lines}%0A%0ATotal%3A%20${total}`,"_blank")}
function toggleMenu(){const n=document.getElementById("nav");n.style.display=n.style.display==="flex"?"none":"flex"}
document.getElementById("contactWhatsApp").href=`https://wa.me/${WHATSAPP_NUMBER}?text=Assalam-o-Alaikum%2C%20I%20want%20to%20order%20from%203H%20Perfume.`;
renderProducts();renderCart();