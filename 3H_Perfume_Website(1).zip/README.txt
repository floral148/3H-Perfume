3H PERFUME WEBSITE
===================

Files:
- index.html
- style.css
- script.js

IMPORTANT:
1. Open script.js.
2. Replace WHATSAPP_NUMBER with your real WhatsApp number in international format.
   Pakistan example: 923001234567 (without + or spaces).
3. Replace sample product names/prices/descriptions in the products array.
4. Open index.html in a browser to test.

VERCEL:
- Create a Vercel account.
- Choose Add New -> Project.
- Upload/import this project folder (or connect a GitHub repository).
- Deploy.
- No paid domain is required; Vercel provides a free vercel.app address.

The design is responsive and includes a cart stored in the browser and WhatsApp checkout.
